﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // محاسبه جمله n فیبوناچی
            int num1 = 0, num2 = 1, sum, i = 0, n;

            Console.WriteLine("Please enter a num:");
            n = int.Parse(Console.ReadLine());

            while (n > i)
            {
                if (i <= 1)
                {
                    Console.Write(i + " ");
                }
                else
                {
                    sum = num1 + num2;
                    num1 = num2;
                    num2 = sum;
                    Console.Write(sum + " ");
                }
                i++;
            }

            Console.WriteLine("press any key to exit...");
            Console.ReadKey();
        }
    }
}
